import java.util.Scanner;

public class exercicio1 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		double base, altura, area, perimetro;
		
		//entrada de dados
		System.out.println("Qual a base? ");
		base = teclado.nextDouble();
		
		System.out.println("Qual a altura? ");
		altura = teclado.nextDouble();
		
		//processamento
		area = base * altura;
		perimetro = 2 * base + 2 * altura;
		
		//saida de dados
		System.out.println("Esta é sua area " + area);
		System.out.println("Este é seu perimetro " + perimetro);

	}

}
